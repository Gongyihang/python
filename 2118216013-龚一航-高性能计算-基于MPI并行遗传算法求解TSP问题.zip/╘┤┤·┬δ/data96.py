import numpy as np

# data962400 = [np.random.permutation(96) for _ in range(240)]
# np.savetxt("data962400.txt",data962400,fmt="%d")

# data962401 = [np.random.permutation(96) for _ in range(240)]
# np.savetxt("data962401.txt",data962401,fmt="%d")

# data962402 = [np.random.permutation(96) for _ in range(240)]
# np.savetxt("data962402.txt",data962402,fmt="%d")

# data962403 = [np.random.permutation(96) for _ in range(240)]
# np.savetxt("data962403.txt",data962403,fmt="%d")

# data96960 = [np.random.permutation(96) for _ in range(960)]
# np.savetxt("data96960.txt",data96960,fmt="%d")

# data96480 = [np.random.permutation(96) for _ in range(480)]
# np.savetxt("data96480.txt",data96480,fmt="%d")

# data964801 = [np.random.permutation(96) for _ in range(480)]
# np.savetxt("data964801.txt",data964801,fmt="%d")


data96320 = [np.random.permutation(96) for _ in range(320)]
np.savetxt("data96320.txt",data96320,fmt="%d")

data963201 = [np.random.permutation(96) for _ in range(320)]
np.savetxt("data963201.txt",data963201,fmt="%d")

data963202 = [np.random.permutation(96) for _ in range(320)]
np.savetxt("data963202.txt",data963202,fmt="%d")
# cities = np.random.rand(96, 2)
# np.savetxt("cities96.txt",cities)